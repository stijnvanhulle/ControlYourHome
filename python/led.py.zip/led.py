#!/usr/bin/env python

import time
import paho.mqtt.client as mqtt
import paho.mqtt.publish as publish
from grovepi import *

# CONNECTORS
led = 4
button = 3

# PINMODES
pinMode(led,"OUTPUT")
pinMode(button,"INPUT")

# MQTT
def on_connect(client, userdata, flags, rc):
	print("Connected with result code "+str(rc))
    
#read FROM MQTT
def on_message(client, userdata, msg):
	print(msg.topic+" "+str(msg.payload))
	if msg.topic=="led":
		waarde=int(msg.payload)


client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
client.connect("raspberrypi.local", 1883, 60)

#subscribe
client.subscribe("led")
#client.unsubscribe("led")

#client.publish("led", "aan")

# LOOP

while True:
    try:
	#client.loop()
    	pressed =(digitalRead(button))
	if pressed==True:
	    digitalWrite(led,1)
	else:
	    digitalWrite(led,0)

    except IOError:
        print ("Error")



